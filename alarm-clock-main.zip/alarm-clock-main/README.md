# alarm-clock
built from scratch using html,css and javascript 
made in simplest way possible providing all the functionalities
